#ifndef lint
static char da_test_lib_hdr_rcsid[] = "$Id: test_rand.h,v 1.1 1996/04/15 22:05:13 agray Exp $";
#endif
/* $Log: test_rand.h,v $
 * Revision 1.1  1996/04/15  22:05:13  agray
 * Initial revision
 *
 * */

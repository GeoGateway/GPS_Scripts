#include <math.h>

int metrop(float de, float t)
{
	float ran3(long *idum);
	static long gljdum=1;

	return de < 0.0 || ran3(&gljdum) < exp(-de/t);
}
